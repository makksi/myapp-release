## Changelog v28

- Update build-exe.yml

---



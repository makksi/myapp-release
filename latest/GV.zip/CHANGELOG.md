## Changelog v26

- fixed CHANGELOG generation in case of no tag

---


